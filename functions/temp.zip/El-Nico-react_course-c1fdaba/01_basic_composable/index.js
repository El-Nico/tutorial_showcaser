function MainContent(){
    return(
        <h1>I'm Learning React</h1>
    )
}

ReactDOM.render(<MainContent/>,document.getElementById("root"))