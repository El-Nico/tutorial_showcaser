ReactDOM.render(<ul>
    <li>1. React</li>
    <li>2. Angular</li>
</ul>, document.getElementById("root"))