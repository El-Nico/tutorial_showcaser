import './main.css'
export function Main(){
    return (
        <main className="mainContainer">
            {/* <img src="https://source.unsplash.com/random/?react,logo" className="background-img"/> */}
        <h1>Fun facts about React</h1>
        <ul>
            <li>Was first released in 2013</li>
        <li>Was originally created by Jordan Walke</li>
        <li>Has well over 100k stars on Github</li>
        <li>is maintained by Facebook</li>
        <li>Powers thousands of enterprise apps, including mobile apps</li>
        </ul>
        </main>
    )
}