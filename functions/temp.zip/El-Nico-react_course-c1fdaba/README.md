17:35
1:00:00 components
1:26:00 multicomponents and styling
<a target="_blank" href="https://icons8.com/icon/wPohyHO_qO1a/react">React</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>

2:05:39 create react app react info site
2:50:32
3:27 jokeapp https://scrimba.com/learn/learnreact/props-part-3-create-a-contact-component-coe1744ae81515a4369f2b32d

4:17:49
